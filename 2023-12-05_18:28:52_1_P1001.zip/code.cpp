#include<iostream>

int a,b;

int main(){
	std::cin>>a>>b;
	std::cout<<a+b<<std::endl;

	return 0;
}
